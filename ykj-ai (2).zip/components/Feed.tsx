import React, { useState, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import PostCard from './PostCard';
import { Post } from '../types';

const Feed: React.FC = () => {
  const { posts, createPost, user } = useAuth();
  const [newTextPost, setNewTextPost] = useState('');
  const [isPosting, setIsPosting] = useState(false);
  const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
  const [attachmentPreview, setAttachmentPreview] = useState<string | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // Revoke previous URL if it exists to prevent memory leaks
    if (attachmentPreview) {
      URL.revokeObjectURL(attachmentPreview);
    }
    
    const file = event.target.files?.[0];
    if (file) {
      setAttachmentFile(file);
      setAttachmentPreview(URL.createObjectURL(file));
    } else {
      setAttachmentFile(null);
      setAttachmentPreview(null);
    }
    // Clear the input value so the same file can be selected again
    if(event.target) event.target.value = '';
  };

  const handleRemoveAttachment = () => {
    if (attachmentPreview) {
      URL.revokeObjectURL(attachmentPreview);
    }
    setAttachmentFile(null);
    setAttachmentPreview(null);
  };

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!newTextPost.trim() && !attachmentFile) || !user) return;
    setIsPosting(true);

    try {
      const postData: Partial<Post> = { text: newTextPost };
      // The attachmentPreview is the blob URL we want to save.
      if (attachmentFile && attachmentPreview) {
        if (attachmentFile.type.startsWith('image/')) {
          postData.imageUrl = attachmentPreview;
        } else if (attachmentFile.type.startsWith('video/')) {
          postData.videoUrl = attachmentPreview;
        }
      }
      
      await createPost(postData);
      
      // Reset state. We don't revoke the URL because it's now owned by the new post in the state.
      setNewTextPost('');
      setAttachmentFile(null);
      setAttachmentPreview(null);

    } catch (error) {
      console.error("Failed to create post", error);
      alert("Something went wrong, please try again.");
    } finally {
      setIsPosting(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto py-6 animate-fade-in">
        {/* Create Post Form */}
        <div className="bg-slate-800/50 rounded-2xl p-4 shadow-xl border border-slate-700 backdrop-blur-sm mb-8">
            <form onSubmit={handlePostSubmit} className="flex flex-col gap-4">
                <div className="flex items-start gap-4">
                    <img src={user?.avatarUrl} alt="Your avatar" className="w-10 h-10 rounded-full flex-shrink-0" />
                    <textarea
                        value={newTextPost}
                        onChange={(e) => setNewTextPost(e.target.value)}
                        placeholder="What's on your mind?"
                        rows={2}
                        className="w-full bg-slate-700 border-2 border-slate-600 rounded-xl p-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors duration-200 resize-none"
                        disabled={isPosting}
                    />
                </div>

                {attachmentPreview && (
                    <div className="relative w-full bg-slate-900/50 rounded-lg overflow-hidden">
                        {attachmentFile?.type.startsWith('image/') ? (
                            <img src={attachmentPreview} alt="Preview" className="max-h-[60vh] rounded-lg w-full object-contain" />
                        ) : (
                            <video src={attachmentPreview} controls className="max-h-[60vh] rounded-lg w-full" />
                        )}
                        <button
                            type="button"
                            onClick={handleRemoveAttachment}
                            className="absolute top-2 right-2 z-10 h-8 w-8 bg-black/60 rounded-full flex items-center justify-center text-white hover:bg-red-600/80 focus:outline-none focus:ring-2 focus:ring-red-400 backdrop-blur-sm transition-all"
                            aria-label="Remove attachment"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                )}

                <div className="flex justify-between items-center mt-2">
                    <div className="flex items-center gap-2">
                        <input type="file" ref={imageInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                        <button
                            type="button"
                            onClick={() => imageInputRef.current?.click()}
                            disabled={isPosting}
                            className="h-10 w-10 flex items-center justify-center text-slate-400 hover:text-green-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            aria-label="Add image"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                            </svg>
                        </button>
                        
                        <input type="file" ref={videoInputRef} onChange={handleFileChange} accept="video/*" className="hidden" />
                        <button
                            type="button"
                            onClick={() => videoInputRef.current?.click()}
                            disabled={isPosting}
                            className="h-10 w-10 flex items-center justify-center text-slate-400 hover:text-blue-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            aria-label="Add video"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 001.553.832l3-2a1 1 0 000-1.664l-3-2z" />
                            </svg>
                        </button>
                    </div>
                    
                    <button
                        type="submit"
                        disabled={(!newTextPost.trim() && !attachmentFile) || isPosting}
                        className="px-5 py-2 bg-purple-600 text-white font-semibold rounded-lg shadow-md hover:bg-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isPosting ? 'Posting...' : 'Post'}
                    </button>
                </div>
            </form>
        </div>
        
        {/* Posts Feed */}
        <div className="space-y-8">
            {posts.map(post => (
                <PostCard key={post.id} post={post} />
            ))}
        </div>
    </div>
  );
};

export default Feed;