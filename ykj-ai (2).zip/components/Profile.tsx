import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import EditProfileModal from './EditProfileModal';

const Profile: React.FC = () => {
    const { user: loggedInUser, posts } = useAuth();
    const [isEditing, setIsEditing] = useState(false);
    
    if (!loggedInUser) {
        return <div className="text-center p-10 text-red-400">Could not load user profile.</div>;
    }
    
    const userPosts = posts.filter(post => post.authorEmail === loggedInUser.email);

  return (
    <>
      <div className="w-full max-w-4xl mx-auto py-6 animate-fade-in">
        {/* Profile Header */}
        <div className="p-6 bg-slate-800/50 rounded-2xl shadow-xl border border-slate-700 backdrop-blur-sm">
            <div className="flex flex-col sm:flex-row items-center gap-6">
                <img
                    src={loggedInUser.avatarUrl}
                    alt={loggedInUser.name}
                    className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-slate-600 shadow-lg object-cover"
                />
                <div className="text-center sm:text-left flex-grow">
                    <h2 className="text-3xl font-bold text-slate-100">{loggedInUser.name}</h2>
                    <p className="text-slate-400">{loggedInUser.email}</p>
                    <p className="text-slate-300 mt-2 text-sm max-w-md italic">
                        {loggedInUser.bio || 'No bio yet.'}
                    </p>
                    <div className="flex items-center justify-center sm:justify-start gap-4 mt-3 text-sm">
                        <span className="font-semibold">{userPosts.length}</span> <span className="text-slate-400">posts</span>
                    </div>
                </div>
                <div className="flex items-center justify-center sm:justify-start gap-3 mt-4 sm:mt-0 sm:self-start">
                    <button onClick={() => setIsEditing(true)} className="px-4 py-2 bg-slate-700 text-slate-300 font-semibold rounded-lg text-sm hover:bg-purple-600 hover:text-white transition-colors duration-200 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>Edit Profile</button>
                </div>
            </div>
        </div>

        {/* Post Gallery */}
        <div className="mt-8">
          <h3 className="text-xl font-bold text-slate-200 mb-4">Posts ({userPosts.length})</h3>
          {userPosts.length > 0 ? (
            <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 sm:gap-4">
              {userPosts.map(post => (
                <div key={post.id} className="post-grid-item group">
                  {post.imageUrl && <img src={post.imageUrl} alt={post.prompt || 'Image post'} />}
                  {post.videoUrl && <video src={post.videoUrl} muted loop playsInline />}
                  {!post.imageUrl && !post.videoUrl && (
                    <div className="flex items-center justify-center p-2 text-center text-xs text-slate-300">
                      {post.text}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    {post.videoUrl && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white/80" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                        </svg>
                    )}
                    {post.imageUrl && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white/80" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                        </svg>
                    )}
                    {post.text && !post.imageUrl && !post.videoUrl && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-slate-800/30 rounded-xl border border-dashed border-slate-700">
              <p className="text-slate-400">{loggedInUser.name} hasn't posted anything yet.</p>
            </div>
          )}
        </div>
      </div>
      {isEditing && loggedInUser && <EditProfileModal user={loggedInUser} onClose={() => setIsEditing(false)} />}
    </>
  );
};

export default Profile;