import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const Header: React.FC = () => {
  const { user } = useAuth();

  return (
    <header className="text-center mb-4 pt-4">
      <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text animate-shimmer">
        YKJ-AI
      </h1>
      <p className="mt-2 text-slate-400 text-lg">
        Welcome, {user?.name || 'Creator'}!
      </p>
    </header>
  );
};

export default Header;
