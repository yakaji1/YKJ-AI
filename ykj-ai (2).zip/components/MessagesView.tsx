import React, { useState } from 'react';
import { BOT_USERS } from '../constants';
import DirectMessageChat from './DirectMessageChat';
import type { User } from '../types';

const MessagesView: React.FC = () => {
    const [selectedBot, setSelectedBot] = useState<User | null>(null);

    if (selectedBot) {
        return <DirectMessageChat botUser={selectedBot} onBack={() => setSelectedBot(null)} />;
    }

    return (
        <div className="w-full max-w-2xl mx-auto py-6 animate-fade-in">
            <h1 className="text-2xl font-bold text-slate-100 mb-6 px-2">Messages</h1>
            <div className="space-y-3">
                {BOT_USERS.map(bot => (
                    <button 
                        key={bot.email}
                        onClick={() => setSelectedBot(bot)}
                        className="w-full flex items-center gap-4 p-4 bg-slate-800/50 rounded-2xl shadow-lg border border-slate-700/80 hover:bg-slate-700/50 hover:border-purple-500/50 transition-all duration-200 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
                    >
                        <img src={bot.avatarUrl} alt={bot.name} className="w-14 h-14 rounded-full flex-shrink-0 object-cover" />
                        <div className="flex-grow">
                            <h2 className="font-bold text-slate-200">{bot.name}</h2>
                            <p className="text-sm text-slate-400 mt-1">{bot.bio}</p>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-500 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                           <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                        </svg>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default MessagesView;
