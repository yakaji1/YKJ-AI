import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const Auth: React.FC = () => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'verify'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  // State for the verification flow
  const [verificationEmail, setVerificationEmail] = useState('');
  const [verificationToken, setVerificationToken] = useState<string | null>(null);

  const { login, register, recoverPassword, verifyAndLogin } = useAuth();

  const handleVerify = async () => {
    if (!verificationToken) {
      setError("Could not find a verification token. Please try registering again.");
      return;
    }
    setError(null);
    try {
      await verifyAndLogin(verificationToken);
      // Successful verification will trigger a login and App re-render via context
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (mode === 'login') {
        await login(email, password);
      } else if (mode === 'register') {
        const result = await register(name, email, password);
        setVerificationEmail(email);
        setVerificationToken(result.verificationToken);
        setMode('verify');
      } else { // 'forgot' mode
        const recoveredPassword = await recoverPassword(email);
        alert(`Password recovery successful!\n\nYour password is: ${recoveredPassword}\n\nPlease use this password to log in.`);
        switchMode('login');
      }
    } catch (err: any) {
      setError(err.message);
    }
  };
  
  const switchMode = (newMode: 'login' | 'register' | 'forgot' | 'verify') => {
      setMode(newMode);
      setError(null);
      setName('');
      setEmail('');
      setPassword('');
      setVerificationEmail('');
      setVerificationToken(null);
  }

  if (mode === 'verify') {
    return (
        <div className="w-full max-w-md mx-auto animate-fade-in text-center">
            <header className="mb-8">
                <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text animate-shimmer">
                    Verify Your Account
                </h1>
            </header>
            <div className="bg-slate-800/50 rounded-2xl p-8 shadow-2xl border border-slate-700 backdrop-blur-sm">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <h2 className="text-2xl font-bold text-slate-200 mt-4 mb-2">Check Your Email</h2>
                <p className="text-slate-400">
                    A verification link has been sent to <strong className="text-slate-300">{verificationEmail}</strong>. Please click the link to activate your account.
                </p>
                {error && (
                    <div className="bg-red-500/20 border border-red-500/50 text-red-300 text-sm p-3 rounded-lg mt-4">
                        {error}
                    </div>
                )}
                <div className="mt-6">
                    <button
                        onClick={handleVerify}
                        className="w-full px-8 py-3 bg-gradient-to-r from-green-500 to-teal-500 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
                    >
                       (Simulate) Click to Verify
                    </button>
                </div>
                 <div className="text-center text-sm text-slate-400 mt-6">
                    <button onClick={() => switchMode('login')} className="font-semibold text-purple-400 hover:underline">
                        Back to Login
                    </button>
                </div>
            </div>
        </div>
    );
  }

  return (
    <div className="w-full max-w-md mx-auto animate-fade-in">
        <header className="text-center mb-8">
            <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text animate-shimmer">
                YKJ-AI
            </h1>
            <p className="mt-2 text-slate-400 text-lg">
                Create & Brainstorm with AI
            </p>
        </header>
        <div className="bg-slate-800/50 rounded-2xl p-8 shadow-2xl border border-slate-700 backdrop-blur-sm">
            <h2 className="text-2xl font-bold text-center text-slate-200 mb-6">
                {mode === 'login' ? 'Welcome Back!' : mode === 'register' ? 'Create an Account' : 'Recover Password'}
            </h2>
            {error && (
                <div className="bg-red-500/20 border border-red-500/50 text-red-300 text-sm p-3 rounded-lg mb-4 text-center">
                    {error}
                </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
                {mode === 'register' && (
                    <input
                        type="text"
                        placeholder="Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        className="w-full bg-slate-700 border-2 border-slate-600 rounded-lg p-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                )}
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full bg-slate-700 border-2 border-slate-600 rounded-lg p-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
                {mode !== 'forgot' && (
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        minLength={6}
                        className="w-full bg-slate-700 border-2 border-slate-600 rounded-lg p-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                )}
                <button
                    type="submit"
                    className="w-full px-8 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
                >
                    {mode === 'login' ? 'Login' : mode === 'register' ? 'Register' : 'Recover Password'}
                </button>
            </form>
            <div className="text-center text-sm text-slate-400 mt-6">
                {mode === 'login' ? (
                    <>
                        <p>
                            Don't have an account?
                            <button onClick={() => switchMode('register')} className="font-semibold text-purple-400 hover:underline ml-1">
                                Register here
                            </button>
                        </p>
                        <p className="mt-2">
                             <button onClick={() => switchMode('forgot')} className="font-semibold text-purple-400 hover:underline">
                                Forgot Password?
                            </button>
                        </p>
                    </>
                ) : mode === 'register' ? (
                     <p>
                        Already have an account?
                        <button onClick={() => switchMode('login')} className="font-semibold text-purple-400 hover:underline ml-1">
                            Login here
                        </button>
                    </p>
                ) : (
                     <p>
                        Remembered your password?
                        <button onClick={() => switchMode('login')} className="font-semibold text-purple-400 hover:underline ml-1">
                            Login here
                        </button>
                    </p>
                )}
            </div>
        </div>
    </div>
  );
};

export default Auth;