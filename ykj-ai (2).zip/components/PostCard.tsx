import React, { useState } from 'react';
import { Post } from '../types';
import { useAuth } from '../contexts/AuthContext';
import VideoResult from './VideoResult';
import ImageResult from './ImageResult';
import { timeSince } from '../utils/time';

interface PostCardProps {
    post: Post;
}

const PostCard: React.FC<PostCardProps> = ({ post }) => {
    const { user, toggleLikePost, addComment } = useAuth();
    const [commentsVisible, setCommentsVisible] = useState(false);
    const [newComment, setNewComment] = useState('');

    if (!user) return null;

    const hasLiked = post.likes.includes(user.email);

    const handleCommentSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim()) return;
        addComment(post.id, newComment);
        setNewComment('');
    };

    return (
        <div className="bg-slate-800/50 rounded-2xl shadow-xl border border-slate-700 backdrop-blur-sm overflow-hidden">
            {/* Post Header */}
            <div className="p-4 flex items-center gap-3">
                <div className="flex items-center gap-3 text-left">
                    <img src={post.authorAvatarUrl} alt={post.authorName} className="w-10 h-10 rounded-full" />
                    <div>
                        <p className="font-semibold text-slate-200">{post.authorName}</p>
                        <p className="text-xs text-slate-400">{timeSince(post.createdAt)} ago</p>
                    </div>
                </div>
            </div>


            {/* Post Content */}
            {post.text && <p className="px-4 pb-4 whitespace-pre-wrap">{post.text}</p>}
            {post.prompt && <p className="px-4 pb-4 text-sm text-slate-400 italic">"{post.prompt}"</p>}

            {post.videoUrl && <div className="bg-black"><VideoResult src={post.videoUrl} /></div>}
            {post.imageUrl && <div className="bg-black"><ImageResult src={post.imageUrl} /></div>}

            {/* Post Actions */}
            <div className="p-4">
                <div className="flex items-center gap-6">
                    <button onClick={() => toggleLikePost(post.id)} className={`flex items-center gap-1.5 group transition-colors duration-200 ${hasLiked ? 'text-pink-500' : 'text-slate-400 hover:text-pink-500'}`}>
                        <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 transition-transform duration-200 group-hover:scale-110 ${hasLiked ? 'fill-current' : 'fill-none'}`} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                           <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                        </svg>
                        <span className="text-sm font-medium">{post.likes.length}</span>
                    </button>
                    <button onClick={() => setCommentsVisible(!commentsVisible)} className="flex items-center gap-1.5 text-slate-400 hover:text-purple-400 transition-colors duration-200">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                        <span className="text-sm font-medium">{post.comments.length}</span>
                    </button>
                </div>
            </div>

            {/* Comments Section */}
            {commentsVisible && (
                <div className="border-t border-slate-700/50 p-4 space-y-4">
                    {/* Existing Comments */}
                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                        {post.comments.map(comment => (
                            <div key={comment.id} className="flex items-start gap-3">
                                <div className="flex-shrink-0">
                                    <img src={comment.authorAvatarUrl} alt={comment.authorName} className="w-8 h-8 rounded-full mt-1" />
                                </div>
                                <div className="flex-1 bg-slate-700/50 rounded-xl p-3">
                                    <div className="flex items-baseline gap-2">
                                        <p className="font-semibold text-sm text-slate-200">{comment.authorName}</p>
                                        <p className="text-xs text-slate-500">{timeSince(comment.createdAt)}</p>
                                    </div>
                                    <p className="text-sm text-slate-300 mt-1">{comment.text}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Add Comment Form */}
                    <form onSubmit={handleCommentSubmit} className="flex items-center gap-3 pt-2">
                        <img src={user.avatarUrl} alt="Your avatar" className="w-8 h-8 rounded-full" />
                        <input
                            type="text"
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder="Add a comment..."
                            className="w-full bg-slate-700 border-2 border-slate-600 rounded-full py-2 px-4 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
                        />
                        <button type="submit" className="text-purple-500 hover:text-purple-400 disabled:opacity-50" disabled={!newComment.trim()}>
                            Post
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
};

export default PostCard;
