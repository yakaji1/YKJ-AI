import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import type { User } from '../types';

interface DirectMessageChatProps {
    botUser: User;
    onBack: () => void;
}

const DirectMessageChat: React.FC<DirectMessageChatProps> = ({ botUser, onBack }) => {
    const { user, conversations, sendDirectMessage } = useAuth();
    const [newMessage, setNewMessage] = useState('');
    const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
    const [attachmentPreview, setAttachmentPreview] = useState<string | null>(null);
    const [isSending, setIsSending] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const conversation = conversations.find(c => c.participants.includes(botUser.email));
    const messages = conversation?.messages || [];
    
    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (attachmentPreview) {
            URL.revokeObjectURL(attachmentPreview);
        }
        const file = event.target.files?.[0];
        if (file) {
            setAttachmentFile(file);
            setAttachmentPreview(URL.createObjectURL(file));
        } else {
            setAttachmentFile(null);
            setAttachmentPreview(null);
        }
        if (event.target) event.target.value = ''; // Allow re-selecting the same file
    };

    const handleRemoveAttachment = () => {
        if (attachmentPreview) {
            URL.revokeObjectURL(attachmentPreview);
        }
        setAttachmentFile(null);
        setAttachmentPreview(null);
    };

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if ((!newMessage.trim() && !attachmentFile) || isSending || !user) return;
        
        setIsSending(true);
        const textToSend = newMessage;
        const fileToSend = attachmentFile;
        
        setNewMessage('');
        setAttachmentFile(null);
        setAttachmentPreview(null);
        
        try {
            await sendDirectMessage(botUser.email, textToSend, fileToSend || undefined);
        } catch (error) {
            console.error("Failed to send message", error);
            // Restore state on failure
            setNewMessage(textToSend);
            setAttachmentFile(fileToSend);
            if(fileToSend) setAttachmentPreview(URL.createObjectURL(fileToSend));
        } finally {
            setIsSending(false);
        }
    };
    
    if (!user) return null;

    return (
        <div className="w-full max-w-2xl mx-auto py-6 animate-fade-in flex flex-col h-[calc(100vh-8rem)]">
            {/* Header */}
            <div className="flex items-center gap-4 pb-4 border-b border-slate-700/80 px-2 mb-4">
                <button onClick={onBack} className="p-2 rounded-full hover:bg-slate-700/50 transition-colors" aria-label="Back to messages">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                    </svg>
                </button>
                <img src={botUser.avatarUrl} alt={botUser.name} className="w-10 h-10 rounded-full object-cover" />
                <h1 className="text-xl font-bold text-slate-100">{botUser.name}</h1>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto px-4 -mx-4 space-y-4">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.senderEmail === user.email ? 'justify-end' : 'justify-start'}`}>
                        <div className={`flex flex-col max-w-md lg:max-w-lg p-1 rounded-2xl shadow ${
                            msg.senderEmail === user.email
                                ? 'bg-purple-600 text-white rounded-br-none'
                                : 'bg-slate-700 text-slate-200 rounded-bl-none'
                        }`}>
                            {msg.imageUrl && (
                                <img src={msg.imageUrl} alt="Attachment" className="rounded-xl max-w-xs object-contain" />
                            )}
                            {msg.videoUrl && (
                                <video src={msg.videoUrl} controls className="rounded-xl max-w-xs" />
                            )}
                            {msg.text && (
                                <p className="whitespace-pre-wrap text-sm sm:text-base px-3 py-1.5">{msg.text}</p>
                            )}
                        </div>
                    </div>
                ))}
                 {isSending && (
                    <div className="flex justify-start">
                        <div className="max-w-md lg:max-w-lg px-4 py-2.5 rounded-2xl shadow bg-slate-700 text-slate-200 rounded-bl-none">
                           <div className="flex items-center gap-2">
                                <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
                                <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></span>
                                <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                           </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            
            {/* Input Form */}
            <form onSubmit={handleSendMessage} className="mt-4 pt-4 border-t border-slate-700/80">
                {attachmentPreview && (
                    <div className="relative self-start mb-2 ml-4 p-1 bg-slate-800 rounded-lg animate-fade-in w-fit">
                        {attachmentFile?.type.startsWith('image/') ? (
                           <img src={attachmentPreview} alt="Attachment preview" className="max-h-24 rounded" />
                        ) : (
                           <video src={attachmentPreview} className="max-h-24 rounded" />
                        )}
                        <button
                            type="button"
                            onClick={handleRemoveAttachment}
                            className="absolute -top-2 -right-2 z-10 h-6 w-6 bg-red-600/90 rounded-full flex items-center justify-center text-white hover:bg-red-500 focus:outline-none focus:ring-2 focus:ring-red-400 backdrop-blur-sm transition-all"
                            aria-label="Remove attachment"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                )}
                 <div className="relative">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="w-full bg-slate-700 border-2 border-slate-600 rounded-full py-3 pl-14 pr-14 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors duration-200"
                        disabled={isSending}
                        aria-label="Chat message input"
                    />
                    <div className="absolute left-2 top-1/2 -translate-y-1/2 flex items-center">
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*,video/*" className="hidden" />
                        <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={isSending}
                            className="h-10 w-10 flex items-center justify-center text-slate-400 hover:text-purple-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            aria-label="Attach file"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                            </svg>
                        </button>
                    </div>
                    <button
                        type="submit"
                        disabled={isSending || (!newMessage.trim() && !attachmentFile)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 bg-purple-600 rounded-full flex items-center justify-center text-white hover:bg-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-110 disabled:scale-100"
                        aria-label="Send message"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                           <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                        </svg>
                    </button>
                 </div>
            </form>
        </div>
    );
};

export default DirectMessageChat;