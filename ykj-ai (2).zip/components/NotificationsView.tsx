import React, { useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Notification } from '../types';
import { timeSince } from '../utils/time';

const NotificationIcon: React.FC<{ type: Notification['type'] }> = ({ type }) => {
    const baseClasses = "h-6 w-6 text-white";
    switch (type) {
        case 'like':
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${baseClasses}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" /></svg>;
        case 'comment':
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${baseClasses}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zM7 8H5v2h2V8zm2 0h2v2H9V8zm6 0h-2v2h2V8z" clipRule="evenodd" /></svg>;
        case 'follow':
             return <svg xmlns="http://www.w3.org/2000/svg" className={`${baseClasses}`} viewBox="0 0 20 20" fill="currentColor"><path d="M8 9a3 3 0 100-6 3 3 0 000 6zM8 11a6 6 0 016 6H2a6 6 0 016-6zM16 11a1 1 0 10-2 0v1h-1a1 1 0 100 2h1v1a1 1 0 102 0v-1h1a1 1 0 100-2h-1v-1z" /></svg>;
        default:
            return null;
    }
};

const getNotificationMessage = (notification: Notification) => {
    const userName = <strong className="font-semibold text-slate-200">{notification.fromUser.name}</strong>;
    switch (notification.type) {
        case 'like':
            return <>{userName} liked your post.</>;
        case 'comment':
            return <>{userName} commented: <span className="text-slate-300 italic">"{notification.textPreview}"</span></>;
        case 'follow':
            return <>{userName} started following you.</>;
        default:
            return 'New notification.';
    }
};


const NotificationsView: React.FC = () => {
    const { notifications, markNotificationsAsRead } = useAuth();

    useEffect(() => {
        const timer = setTimeout(() => {
            markNotificationsAsRead();
        }, 1000); // Delay allows user to see the dot disappear
        return () => clearTimeout(timer);
    }, [markNotificationsAsRead]);

    return (
        <div className="w-full max-w-2xl mx-auto py-6 animate-fade-in">
            <h1 className="text-2xl font-bold text-slate-100 mb-6 px-2">Notifications</h1>

            {notifications.length > 0 ? (
                <div className="space-y-3">
                    {notifications.map(notification => (
                        <div key={notification.id} className="w-full flex items-start gap-4 p-4 bg-slate-800/50 rounded-2xl shadow-lg border border-slate-700/80">
                            <div className={`relative flex-shrink-0 mt-1`}>
                                <img src={notification.fromUser.avatarUrl} alt={notification.fromUser.name} className="w-10 h-10 rounded-full object-cover" />
                                <span className={`absolute -bottom-1 -right-1 p-1 rounded-full border-2 border-slate-800 ${notification.type === 'like' ? 'bg-pink-500' : 'bg-purple-500'}`}>
                                    <NotificationIcon type={notification.type} />
                                </span>
                            </div>
                            <div className="flex-grow">
                                <p className="text-sm text-slate-300">
                                    {getNotificationMessage(notification)}
                                </p>
                                <p className="text-xs text-slate-500 mt-1">
                                    {timeSince(notification.createdAt)} ago
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-20 bg-slate-800/30 rounded-xl border border-dashed border-slate-700">
                    <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                    <p className="mt-4 text-lg font-medium text-slate-400">No Notifications Yet</p>
                    <p className="mt-1 text-sm text-slate-500">Likes and comments on your posts will appear here.</p>
                </div>
            )}
        </div>
    );
};

export default NotificationsView;
