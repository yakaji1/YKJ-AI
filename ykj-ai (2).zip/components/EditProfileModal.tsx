import React, { useState, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { User } from '../types';

interface EditProfileModalProps {
  user: User;
  onClose: () => void;
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ user, onClose }) => {
  const { updateUserProfile } = useAuth();
  const [bio, setBio] = useState(user.bio || '');
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null); // Clear previous errors
    const file = e.target.files?.[0];
    if (file) {
      // Basic validation for file type and size
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file (PNG, JPG, etc.).');
        return;
      }
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError('Image is too large. Please select a file under 5MB.');
        return;
      }
      setAvatarFile(file);
      if (avatarPreview) {
        URL.revokeObjectURL(avatarPreview);
      }
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  const handleSave = async () => {
    setError(null);
    setIsSaving(true);
    try {
      await updateUserProfile({ avatarFile: avatarFile || undefined, bio });
      onClose();
    } catch (error: any) {
      console.error("Failed to update profile", error);
      setError(error.message || "An unknown error occurred. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl shadow-2xl border border-slate-700 w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
        <h2 className="text-2xl font-bold text-white mb-6">Edit Profile</h2>
        
        <div className="flex items-center gap-4 mb-6">
          <img src={avatarPreview || user.avatarUrl} alt="Profile preview" className="w-20 h-20 rounded-full object-cover border-2 border-slate-600" />
          <button onClick={() => fileInputRef.current?.click()} className="px-4 py-2 bg-slate-700 text-slate-300 font-semibold rounded-lg text-sm hover:bg-slate-600 transition-colors">
            Change Photo
          </button>
          <input type="file" ref={fileInputRef} onChange={handleAvatarChange} accept="image/png, image/jpeg, image/webp" className="hidden" />
        </div>
        
        <div>
          <label htmlFor="bio" className="block text-sm font-medium text-slate-400 mb-2">Bio</label>
          <textarea 
            id="bio" 
            value={bio} 
            onChange={e => setBio(e.target.value)} 
            rows={3} 
            maxLength={150} 
            className="w-full bg-slate-700 border-2 border-slate-600 rounded-lg p-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors duration-200 resize-none" 
            placeholder="Tell us a bit about yourself..." 
          />
          <p className="text-right text-xs text-slate-500 mt-1">{bio.length}/150</p>
        </div>

        {error && (
            <div className="bg-red-500/20 border border-red-500/50 text-red-300 text-sm p-3 rounded-lg mt-4 text-center">
                {error}
            </div>
        )}
        
        <div className="flex justify-end gap-4 mt-6">
          <button onClick={onClose} className="px-5 py-2 bg-slate-600/50 text-slate-300 font-semibold rounded-lg hover:bg-slate-600 transition-colors disabled:opacity-50" disabled={isSaving}>
            Cancel
          </button>
          <button onClick={handleSave} className="px-5 py-2 bg-purple-600 text-white font-bold rounded-lg shadow-md hover:bg-purple-700 transition-all disabled:opacity-50 disabled:cursor-wait" disabled={isSaving}>
            {isSaving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditProfileModal;
