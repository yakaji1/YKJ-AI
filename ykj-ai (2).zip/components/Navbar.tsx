import React from 'react';
import { useAuth } from '../contexts/AuthContext';

type View = 'Create' | 'Feed' | 'Messages' | 'Notifications' | 'Profile';

interface NavbarProps {
  activeView: View;
  onViewChange: (view: View) => void;
}

const NavButton: React.FC<{
  label: View;
  isActive: boolean;
  onClick: () => void;
  icon: JSX.Element;
  hasNotification?: boolean;
}> = ({ label, isActive, onClick, icon, hasNotification = false }) => (
    <button
        onClick={onClick}
        className={`relative flex-1 flex flex-col items-center justify-center gap-1 py-2 px-3 text-xs sm:text-sm font-medium transition-colors duration-300 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 focus-visible:ring-purple-500 ${
            isActive ? 'text-purple-400' : 'text-slate-400 hover:text-white'
        }`}
    >
        {hasNotification && (
            <span className="absolute top-1 right-1/2 translate-x-3 w-2 h-2 bg-red-500 rounded-full border-2 border-slate-800"></span>
        )}
        {icon}
        <span>{label}</span>
    </button>
);

const Navbar: React.FC<NavbarProps> = ({ activeView, onViewChange }) => {
    const { notifications } = useAuth();
    const hasUnreadNotifications = notifications.some(n => !n.read);

    const icons = {
        Create: (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
            </svg>
        ),
        Feed: (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3h2m-4 3h2m-4 3h2" />
            </svg>
        ),
        Messages: (
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
        ),
        Notifications: (
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
        ),
        Profile: (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
        ),
    };

    return (
        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-slate-800/80 backdrop-blur-lg border-t border-slate-700 z-50">
            <div className="max-w-4xl mx-auto h-full flex items-center justify-around px-2">
                <NavButton label="Create" isActive={activeView === 'Create'} onClick={() => onViewChange('Create')} icon={icons.Create} />
                <NavButton label="Feed" isActive={activeView === 'Feed'} onClick={() => onViewChange('Feed')} icon={icons.Feed} />
                <NavButton label="Messages" isActive={activeView === 'Messages'} onClick={() => onViewChange('Messages')} icon={icons.Messages} />
                <NavButton label="Notifications" isActive={activeView === 'Notifications'} onClick={() => onViewChange('Notifications')} icon={icons.Notifications} hasNotification={hasUnreadNotifications} />
                <NavButton label="Profile" isActive={activeView === 'Profile'} onClick={() => onViewChange('Profile')} icon={icons.Profile} />
            </div>
        </nav>
    );
};

export default Navbar;
