export enum Tab {
  Video = 'Video',
  Photo = 'Photo',
  ImageToVideo = 'ImageToVideo',
  EditImage = 'EditImage',
  EditVideo = 'EditVideo',
  AIChat = 'AIChat',
}

export type AspectRatio = '16:9' | '1:1' | '9:16';
export type Quality = 'Standard' | 'HD';

// A single part of a message, can be text or an image
export type MessagePart = {
  text?: string;
  // Store the image as a data URL for easy rendering in the UI
  imageData?: {
    url: string; // The data URL string
    mimeType: string;
  };
};

// A full message in the chat history, composed of one or more parts
export type ChatMessage = {
  role: 'user' | 'model';
  parts: MessagePart[];
};

export type Inspiration = {
  prompt: string;
  thumbnailUrl: string;
};

export type ViralShort = {
  prompt: string;
  videoUrl: string;
};

export type EditTemplate = {
  prompt: string;
  beforeUrl: string;
  afterUrl: string;
};

export type MusicTrack = {
  name: string;
  url: string;
};

export type User = {
    name: string;
    email: string;
    avatarUrl: string;
    bio?: string;
    following: string[]; // Array of user emails
    followers: string[]; // Array of user emails
    personality?: string; // System instruction for AI bots
};

// --- New Social Media Types ---
export type Comment = {
  id: string;
  authorEmail: string;
  authorName: string;
  authorAvatarUrl: string;
  text: string;
  createdAt: string;
};

export type Post = {
  id: string;
  authorEmail: string;
  authorName:string;
  authorAvatarUrl: string;
  createdAt: string;
  // Content
  prompt?: string; // For AI generations
  text?: string; // For text-only posts
  videoUrl?: string;
  imageUrl?: string;
  // Social
  likes: string[]; // Array of user emails
  comments: Comment[];
};

// --- New Direct Messaging Types ---
export type DirectMessage = {
    id: string;
    senderEmail: string;
    text: string;
    imageUrl?: string;
    videoUrl?: string;
    createdAt: string;
};

export type Conversation = {
    id: string; // e.g., 'user_email-bot_email' sorted alphabetically
    participants: string[]; // Array of two user emails
    messages: DirectMessage[];
};

// --- New Notification Type ---
export type Notification = {
  id: string;
  type: 'like' | 'comment' | 'follow';
  fromUser: {
    name: string;
    avatarUrl: string;
    email: string;
  };
  postId?: string; // Link to the post for likes/comments
  textPreview?: string; // For comment notifications
  createdAt: string;
  read: boolean;
};
