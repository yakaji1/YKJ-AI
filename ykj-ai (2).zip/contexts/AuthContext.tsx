// FIX: Add DOM library reference to resolve 'localStorage' and other DOM API type errors.
/// <reference lib="dom" />

import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { User, Post, Comment, Conversation, DirectMessage, Notification } from '../types';
import { DEFAULT_AVATAR, BOT_USERS } from '../constants';
import { GoogleGenAI } from "@google/genai";

// --- MOCK GUEST USER ---
const GUEST_USER: User = {
    name: 'Guest User',
    email: 'guest@example.com',
    avatarUrl: DEFAULT_AVATAR,
    bio: 'Exploring the world of AI creation!',
    following: [],
    followers: [],
};


// --- MOCK DATA FOR DEMO ---
const INITIAL_POSTS: Post[] = [
    {
        id: 'post1',
        authorEmail: 'demouser@example.com',
        authorName: 'Demo User',
        authorAvatarUrl: DEFAULT_AVATAR,
        createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
        prompt: "A neon hologram of a cat driving at top speed, photorealistic, 16:9 aspect ratio",
        videoUrl: "https://player.vimeo.com/progressive_redirect/playback/926953765/rendition/540p/file.mp4?loc=external&oauth2_token_id=57447761&signature=130058f3ca3916f19489a27f6786f32810a78631c3eb725c8e3b50c0c2c1f308",
        likes: [],
        comments: [],
    },
    {
        id: 'post2',
        authorEmail: 'demouser@example.com',
        authorName: 'Demo User',
        authorAvatarUrl: DEFAULT_AVATAR,
        createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        text: "Just created this amazing video with YKJ-AI! What do you all think?",
        likes: ['anotheruser@example.com'],
        comments: [
            {
                id: 'comment1',
                authorEmail: 'anotheruser@example.com',
                authorName: 'Another User',
                authorAvatarUrl: DEFAULT_AVATAR,
                text: "Wow, that looks incredible! Great job.",
                createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
            }
        ],
    },
     {
        id: 'post3',
        authorEmail: 'demouser@example.com',
        authorName: 'Demo User',
        authorAvatarUrl: DEFAULT_AVATAR,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
        prompt: "A majestic lion with a crown, photorealistic, 1:1 aspect ratio",
        imageUrl: "https://images.pexels.com/photos/2220336/pexels-photo-2220336.jpeg?auto=compress&cs=tinysrgb&w=600",
        likes: [],
        comments: [],
    }
];

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface AuthContextType {
  user: User | null;
  posts: Post[];
  conversations: Conversation[];
  notifications: Notification[];
  // Mocked functions
  login: (email: string, password:string) => Promise<void>;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<{ verificationToken: string }>;
  recoverPassword: (email: string) => Promise<string>;
  verifyAndLogin: (token: string) => Promise<void>;
  // Functional for guest user
  createPost: (postData: Partial<Post>) => Promise<void>;
  toggleLikePost: (postId: string) => void;
  addComment: (postId: string, text: string) => void;
  updateUserProfile: (profileData: { avatarFile?: File; bio?: string }) => Promise<void>;
  sendDirectMessage: (recipientEmail: string, text: string, file?: File) => Promise<void>;
  markNotificationsAsRead: () => void;
  // Mocked social functions
  searchUsers: (query: string) => Promise<User[]>;
  followUser: (targetEmail: string) => Promise<void>;
  unfollowUser: (targetEmail: string) => Promise<void>;
  getUserProfile: (email: string) => Promise<User | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(GUEST_USER);
  const [posts, setPosts] = useState<Post[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const loadData = (key: string, setter: Function, initialData?: any) => {
        try {
            const savedData = localStorage.getItem(key);
            if (savedData) {
                setter(JSON.parse(savedData));
            } else if (initialData) {
                localStorage.setItem(key, JSON.stringify(initialData));
                setter(initialData);
            }
        } catch (error) {
            console.error(`Failed to parse ${key} from localStorage`, error);
        }
    };
    loadData('ykj-ai-posts', setPosts, INITIAL_POSTS);
    loadData('ykj-ai-conversations', setConversations, []);
    loadData('ykj-ai-notifications', setNotifications, []);
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    const saveData = (key: string, data: any) => {
        try {
             localStorage.setItem(key, JSON.stringify(data));
        } catch (error) {
            console.error(`Failed to save ${key} to localStorage`, error);
        }
    };
    saveData('ykj-ai-posts', posts);
    saveData('ykj-ai-conversations', conversations);
    saveData('ykj-ai-notifications', notifications);
  }, [posts, conversations, notifications]);


  // Mock authentication functions
  const login = async (): Promise<void> => { console.warn("Login is disabled."); };
  const register = async (): Promise<{ verificationToken: string }> => {
    console.warn("Registration is disabled.");
    return { verificationToken: '' };
  };
  const verifyAndLogin = async (): Promise<void> => { console.warn("Verification is disabled."); };
  const recoverPassword = async (): Promise<string> => {
    console.warn("Password recovery is disabled.");
    return '';
  };
  const logout = () => { console.warn("Logout is disabled."); };
  
    const generateBotActivity = (post: Post) => {
        if (!user || post.authorEmail !== user.email) return;

        if (Math.random() > 0.4) { // 60% chance of interaction
            const randomBot = BOT_USERS[Math.floor(Math.random() * BOT_USERS.length)];
            const delay = Math.random() * 10000 + 4000; // 4-14 second delay

            setTimeout(() => {
                if (Math.random() > 0.4) { // 60% chance of a like
                    setPosts(currentPosts => currentPosts.map(p => {
                        if (p.id === post.id && !p.likes.includes(randomBot.email)) {
                            return { ...p, likes: [...p.likes, randomBot.email] };
                        }
                        return p;
                    }));
                    const newNotification: Notification = {
                        id: `notif_like_${Date.now()}`, type: 'like',
                        fromUser: { name: randomBot.name, avatarUrl: randomBot.avatarUrl, email: randomBot.email },
                        postId: post.id, createdAt: new Date().toISOString(), read: false,
                    };
                    setNotifications(prev => [newNotification, ...prev]);
                } else { // 40% chance of a comment
                    const botComments = ["Looks amazing!", "Great work!", "So cool!", "Love this idea.", "Incredible result!"];
                    const botCommentText = botComments[Math.floor(Math.random() * botComments.length)];
                    const newComment: Comment = {
                        id: `comment_${Date.now()}`, authorEmail: randomBot.email, authorName: randomBot.name,
                        authorAvatarUrl: randomBot.avatarUrl, text: botCommentText, createdAt: new Date().toISOString(),
                    };
                    setPosts(currentPosts => currentPosts.map(p => {
                        if (p.id === post.id) return { ...p, comments: [...p.comments, newComment] };
                        return p;
                    }));
                    const newNotification: Notification = {
                        id: `notif_comment_${Date.now()}`, type: 'comment',
                        fromUser: { name: randomBot.name, avatarUrl: randomBot.avatarUrl, email: randomBot.email },
                        postId: post.id, textPreview: botCommentText, createdAt: new Date().toISOString(), read: false,
                    };
                    setNotifications(prev => [newNotification, ...prev]);
                }
            }, delay);
        }
    };

  const createPost = async (postData: Partial<Post>): Promise<void> => {
      if (!user) throw new Error("A user must be available to post.");
      const newPost: Post = {
        id: `post_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
        authorEmail: user.email,
        authorName: user.name,
        authorAvatarUrl: user.avatarUrl,
        createdAt: new Date().toISOString(),
        likes: [],
        comments: [],
        ...postData,
      };
      setPosts(prevPosts => [newPost, ...prevPosts]);
      generateBotActivity(newPost);
  };
  
  const toggleLikePost = (postId: string) => {
      if (!user) return;
      setPosts(posts.map(post => {
          if (post.id === postId) {
              const liked = post.likes.includes(user.email);
              const likes = liked ? post.likes.filter(email => email !== user.email) : [...post.likes, user.email];
              return { ...post, likes };
          }
          return post;
      }));
  };

  const addComment = (postId: string, text: string) => {
      if (!user) return;
      const newComment: Comment = {
          id: `comment_${Date.now()}`,
          authorEmail: user.email,
          authorName: user.name,
          authorAvatarUrl: user.avatarUrl,
          text: text,
          createdAt: new Date().toISOString(),
      };
      setPosts(posts.map(post => {
          if (post.id === postId) {
              return { ...post, comments: [...post.comments, newComment] };
          }
          return post;
      }));
  };
  
    const updateUserProfile = async (profileData: { avatarFile?: File; bio?: string }) => {
        if (!user) throw new Error("User not available");

        let newAvatarUrl: string | undefined = undefined;
        if (profileData.avatarFile) {
            newAvatarUrl = await new Promise<string>((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result as string);
                reader.onerror = error => reject(error);
                reader.readAsDataURL(profileData.avatarFile!);
            });
        }
        
        const updatedUser = {
            ...user,
            bio: typeof profileData.bio === 'string' ? profileData.bio : user.bio,
            avatarUrl: newAvatarUrl || user.avatarUrl,
        };
        setUser(updatedUser);

        setPosts(prevPosts => {
            return prevPosts.map(post => {
                let authorAvatarUrl = post.authorAvatarUrl;
                if (post.authorEmail === user.email) {
                    authorAvatarUrl = updatedUser.avatarUrl;
                }

                const updatedComments = post.comments.map(comment => {
                    if (comment.authorEmail === user.email) {
                        return { ...comment, authorAvatarUrl: updatedUser.avatarUrl };
                    }
                    return comment;
                });

                return { ...post, authorAvatarUrl, comments: updatedComments };
            });
        });
    };

    const sendDirectMessage = async (recipientEmail: string, text: string, file?: File) => {
        if (!user) throw new Error("User not authenticated");
    
        const bot = BOT_USERS.find(b => b.email === recipientEmail);
        if (!bot || !bot.personality) throw new Error("Bot not found or has no personality.");
    
        const conversationId = [user.email, recipientEmail].sort().join('-');
        
        let imageUrl: string | undefined;
        let videoUrl: string | undefined;
        if (file) {
            const objectUrl = URL.createObjectURL(file);
            if (file.type.startsWith('image/')) {
                imageUrl = objectUrl;
            } else if (file.type.startsWith('video/')) {
                videoUrl = objectUrl;
            }
        }

        const userMessage: DirectMessage = {
            id: `dm_${Date.now()}`,
            senderEmail: user.email,
            text,
            imageUrl,
            videoUrl,
            createdAt: new Date().toISOString(),
        };

        // Update state with user's message immediately for good UX
        let updatedConversation: Conversation;
        setConversations(prev => {
            const existingConvo = prev.find(c => c.id === conversationId);
            if (existingConvo) {
                updatedConversation = { ...existingConvo, messages: [...existingConvo.messages, userMessage] };
                return prev.map(c => c.id === conversationId ? updatedConversation : c);
            } else {
                updatedConversation = { id: conversationId, participants: [user.email, recipientEmail], messages: [userMessage] };
                return [...prev, updatedConversation];
            }
        });
        
        try {
            const history = updatedConversation!.messages
              .filter(msg => msg.text) // Only include messages with text for the AI
              .map(msg => ({
                role: msg.senderEmail === user.email ? 'user' : 'model',
                parts: [{ text: msg.text }],
            }));

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: history,
                config: {
                    systemInstruction: bot.personality,
                },
            });

            const botMessage: DirectMessage = {
                id: `dm_${Date.now() + 1}`,
                senderEmail: bot.email,
                text: response.text,
                createdAt: new Date().toISOString(),
            };

            setConversations(prev => prev.map(c => 
                c.id === conversationId 
                ? { ...c, messages: [...c.messages, botMessage] } 
                : c
            ));
        } catch (error) {
            console.error("Error sending message to Gemini:", error);
            const errorMessage: DirectMessage = {
                id: `dm_error_${Date.now()}`,
                senderEmail: bot.email,
                text: "Sorry, I'm having trouble connecting right now. Please try again later.",
                createdAt: new Date().toISOString(),
            };
            setConversations(prev => prev.map(c => 
                c.id === conversationId 
                ? { ...c, messages: [...c.messages, errorMessage] } 
                : c
            ));
        }
    };

    const markNotificationsAsRead = () => {
        setNotifications(prev => prev.map(n => ({...n, read: true})));
    };
    
    // Mocked social functions
    const searchUsers = async (): Promise<User[]> => { return []; };
    const getUserProfile = async (email: string): Promise<User | null> => {
        if (email === GUEST_USER.email) return user;
        return BOT_USERS.find(b => b.email === email) || null;
    };
    const followUser = async (): Promise<void> => { console.warn("Following is disabled."); };
    const unfollowUser = async (): Promise<void> => { console.warn("Unfollowing is disabled."); };


  return (
    <AuthContext.Provider value={{ user, posts, conversations, notifications, login, logout, register, recoverPassword, verifyAndLogin, createPost, toggleLikePost, addComment, updateUserProfile, sendDirectMessage, markNotificationsAsRead, searchUsers, getUserProfile, followUser, unfollowUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
